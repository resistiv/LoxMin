#ifndef loxmin_object_h
#define loxmin_object_h

#include "common.h"
#include "chunk.h"
#include "value.h"

/**
 * @brief Enumerates all available Object types.
 */
typedef enum
{
    OBJECT_FUNCTION,
    OBJECT_NATIVE,
    OBJECT_STRING,
} ObjectType;

/**
 * @brief Represents an object.
 */
struct Object 
{
    ObjectType type;
    struct Object* next;
};

/**
 * @brief Represents a string.
 */
struct ObjectString
{
    Object obj;
    int length;
    char* chars;
    uint32_t hash;
};

/**
 * @brief Represents a function.
 */
typedef struct
{
    Object obj;
    int arity;
    Chunk chunk;
    ObjectString* name;
} ObjectFunction;

typedef Value (*NativeFn)(int argCount, Value* args);

/**
 * @brief Represents a native function.
 */
typedef struct
{
    Object obj;
    NativeFn function;
} ObjectNative;

#define OBJECT_TYPE(value)  (AS_OBJECT(value)->type)

#define IS_FUNCTION(value)  IsObjectType(value, OBJECT_FUNCTION)
#define IS_NATIVE(value)    IsObjectType(value, OBJECT_NATIVE)
#define IS_STRING(value)    IsObjectType(value, OBJECT_STRING)

#define AS_FUNCTION(value)  ((ObjectFunction*)AS_OBJECT(value))
#define AS_NATIVE(value)    (((ObjectNative*)AS_OBJECT(value))->function)
#define AS_STRING(value)    ((ObjectString*)AS_OBJECT(value))
#define AS_CSTRING(value)   (((ObjectString*)AS_OBJECT(value))->chars)

/**
 * @brief Instantiates a new function.
 * 
 * @return ObjectFunction* A pointer to the new ObjectFunction object.
 */
ObjectFunction* NewFunction();

/**
 * @brief Instantiates a new native function.
 * 
 * @param function A native function.
 * @return ObjectNative* A pointer to the new ObjectNative object.
 */
ObjectNative* NewNative(NativeFn function);

/**
 * @brief Takes ownership of a given string and allocates it.
 * 
 * @param chars A pointer to the string's characters.
 * @param length The length of the string.
 * @return ObjectString* A pointer to the resulting ObjectString.
 */
ObjectString* TakeString(char* chars, int length);

/**
 * @brief Copies a string into memory and creates an ObjectString object.
 * 
 * @param chars A pointer to the characters to copy.
 * @param length The length of the string.
 * @return ObjectString* A pointer to the resulting ObjectString.
 */
ObjectString* CopyString(const char* chars, int length);

/**
 * @brief Prints an Object and its contents in a human-readable form.
 * 
 * @param value A Value holding an Object.
 */
void PrintObject(Value value);

/**
 * @brief Checks if a Value is an Object and its type matches a given ObjectType.
 * 
 * @param value A Value to check.
 * @param type An ObjectType to verify.
 * @return true If the Value is an Object and its type matches the specified ObjectType.
 * @return false If the Value is not Object or its type does not match the specified ObjectType.
 */
static inline bool IsObjectType(Value value, ObjectType type)
{
    return IS_OBJECT(value) && OBJECT_TYPE(value) == type;
}

#endif
